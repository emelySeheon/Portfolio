/*
Program: Functions.h
Programmer: Emely Seheon (eseheon1@cnm.edu)
Date: 10/6/20
Purpose: To provide functions for the driver.
*/

using namespace std;

#ifndef _FUNCTIONS_H
#define _FUNCTIONS_H

void WriteHeader();
void AskForMonthAndYear(int& month, int& year);

#endif