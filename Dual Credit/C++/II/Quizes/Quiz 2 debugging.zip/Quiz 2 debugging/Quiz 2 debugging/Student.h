//File: Student.h

#ifndef _STUDENT_H
#define _STUDENT_H


using namespace std;

class Student
{
private:
	string name, ID;
	int testScore[4] = 0;
	double ave{ 0.0 };

public:
	Student() = default;

	void SetNameID(string n, string i);
	void SetTestScores(int sc[]);
	
	double GetAverage(){ return ave; }
	string GetName(){ return name; }
	string GetID(){ return ID; }
};

#endif

