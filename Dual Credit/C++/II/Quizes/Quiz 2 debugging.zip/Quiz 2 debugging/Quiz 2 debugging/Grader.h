//File: Grader.h

#ifndef _GRADER_H
#define _GRADER_H

#include "Student.h"
#include <string>
using namespace std;

class Grader
{
private:
	Student kids[10];
	int total{ 0 };
	string courseName, courseID, college; 
	double courseAve{ 0.0 }, courseHigh{ 0.0 }, courseLow{ 0.0 };
	int highKid{ 0 }, lowKid{ 0 };
	string file;
	string courseStats;
	bool bReadFile{ false };
	void ReadStudentFile();

public:
	Grader() = default;
	void ComputeCourseStats();
	string GetCourseStats(){ return courseStats; }
	bool WriteResultsFile(string file, string* course_name);
	bool IsFileRead{ return bReadFile; }
	int GetTotal(){ return total; }
}

#endif
