//File: Student.cpp

#include "Student.h"

Student::Student()
{}

void Student::SetNameID(string n, string i)
{
	name = n;
	ID = i;
}

void Student::SetTestScores(int sc[])
{
	int i;
	
	//copy the test scores into the array
	testScore = sc;
	
	
	int sum = 0;
	
	
	//sum and determine average
	for(i = 0; i < 4; ++i)
		sum += testScore[i];

	ave = sum/4;
}

