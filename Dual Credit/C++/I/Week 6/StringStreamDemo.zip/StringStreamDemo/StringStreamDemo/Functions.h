/*
Program: Emely Seheon
Programmer: Emely Seheon (eseheon1@cnm.edu)
Date: 6/23/20
Purpose: Provide functions needed in StringStreamDemo
preject.
*/

#ifndef _FUNCTIONS_H
#define _FUNCTIONS_H

#include <iostream>;
#include <sstream>;
using namespace std;

string GetBankBalSummary(float balance);

#endif