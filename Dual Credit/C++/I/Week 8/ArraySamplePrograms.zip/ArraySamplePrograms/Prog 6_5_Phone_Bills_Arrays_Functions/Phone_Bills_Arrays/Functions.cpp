//A program to calculate phone bill average for
//the year. It uses two functions, one to fill the
//array, one to sum and calculate the average.

//Functions.cpp

#include <iostream>
#include <string>
#include "Functions.h"
using namespace std;

//Function to ask for monthly bill data.
void AskBillData(string month[], float bills[])
{
	// Obtain monthly billing information 
	for(int i = 0; i < 12; ++i) 
	{
		cout << " Enter bill for month " << i + 1 << " $";
		cin >> bills[i];
	}
}

//Function that determines bill average,
//given the yearly sum.
float CalcBillTotalandAve(float bills[], float &rSum)
{
	rSum = 0.0;
	for(int i = 0; i < 12; ++i)  
	{
		rSum = rSum + bills[i];
	}

	return rSum/12.0;
}