//A program to calculate phone bill average for
//the year. It uses two functions, one to fill the
//array, one to sum and calculate the average.

#include <iostream>
#include <string>
#include "Functions.h"
using namespace std;



int main()
{
	// Declare an array of 12 floats
	float phone_bills[12];       

	//Declare and initialize the names of the months:
	string month[12] = {"Jan", "Feb", "Mar", "Apr",
					"May", "June", "July", "Aug",
					"Sept", "Oct", "Nov", "Dec" };

	cout << "\n A program that determines yearly total"
		<< "\n and average monthly phone bill.\n\n";

	//use array names in call statements 
	//(arrays addresses are actually passed to functions)
	AskBillData(month,phone_bills);


	float ave, sum;
	ave = CalcBillTotalandAve(phone_bills, sum);

	cout.precision(2);
	cout.setf(ios::fixed);
	cout << "\n Total yearly phone cost is $" << sum
		<< "\n Average monthly phone bill is $"
		<< ave << endl;

	return 0;
}




