//A program to calculate phone bill average for
//the year. It uses two functions, one to fill the
//array, one to sum and calculate the average.

//Functions.h

#include <string>
using namespace std;


//Function declarations use [] to indicate arrays
void AskBillData(string month[], float bills[]);

//return the average, use a reference for the sum
float CalcBillTotalandAve(float bills[], float &rSum);