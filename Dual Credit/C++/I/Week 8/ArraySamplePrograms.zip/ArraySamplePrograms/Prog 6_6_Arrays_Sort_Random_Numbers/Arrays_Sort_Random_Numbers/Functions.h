//A program that generates 100 random numbers
//in one function and uses a bubble sort to 
//sort the array.

//Functions.h

//functions need array [] in prototype

void Sort(int numbers[], int total);  
void GenRandNums(int numbers[], int total);
void ShowFirstLast5(int numbers[], int total);  