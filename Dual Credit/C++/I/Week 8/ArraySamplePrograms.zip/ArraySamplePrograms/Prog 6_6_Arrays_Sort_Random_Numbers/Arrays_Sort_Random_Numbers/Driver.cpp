//A program that generates 100 random numbers
//in one function and uses a bubble sort to 
//sort the array.

#include <iostream>
#include "Functions.h"
using namespace std;



						   
int main()
{
	int numbers[100], total = 100;

	cout << "\n\n This is a program that generates 100 random numbers\n"
		 << " in one function and uses a bubble sort to sort the array.\n";
	cout << "\n\n Make 'em, Show 'em, Sort 'em, Show 'em again. ";


	GenRandNums(numbers, total);

	cout << "\n Here are the unsorted values.";
	ShowFirstLast5(numbers, total);

	Sort(numbers, total);

	cout << "\n Here are the sorted values.";
	ShowFirstLast5(numbers, total);

	cout<<endl<<endl;
	return 0;
}



