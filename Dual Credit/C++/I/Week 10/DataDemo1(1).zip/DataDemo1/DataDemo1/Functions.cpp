//Program: FileDemo
//Programmer: Rob Garner
//Date: Today
//Purpose: Learn how to use files in C++

#include <iostream>
#include <string>
#include <fstream>
#include "functions.h"

using namespace std;

void ReadFile(double waterQ[], int &count)
{
	ifstream infile;
	infile.open("EQI_RESULTS_2013JULY22.CSV");

	string discard;
	getline(infile, discard);

	//string line;
	double num;
	int lineIndex = 0;
	while (!infile.eof())
	{
		//Priming read
		getline(infile, discard, ',');
		if (discard!="")//Don't process empty lines
		{
			for (int skipIndex = 0; skipIndex < 4; ++skipIndex)//Discard 4 elements
			{
				getline(infile, discard, ',');
			}
			infile >> waterQ[lineIndex];//Read in one element
			getline(infile, discard);//Discard rest of line
			lineIndex = lineIndex + 1; //Get next line
		}
	}
	count = lineIndex;
	infile.close();
}

void Average(double array[], int count, double &sum, double &average)
{
	sum = 0;
	for (int i = 0; i < count; ++i)
	{
		sum += array[i];
	}
	average = sum / count;
	return;
}