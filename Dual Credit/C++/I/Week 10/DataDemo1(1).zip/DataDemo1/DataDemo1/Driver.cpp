//Program: FileDemo
//Programmer: Rob Garner
//Date: Today
//Purpose: Learn how to read data

#include <iostream>
#include <string>
#include <fstream>
#include "functions.h"

using namespace std;

int main()
{
	double waterQ[3500];
	int count;
	ReadFile(waterQ, count);

	for (int i = 0; i < count; ++i)
	{
		cout << waterQ[i]<< endl;
	}

	double sum;
	double average;
	Average(waterQ, count, sum, average);
	cout << "Total is: " << sum << endl;
	cout << "Average is: " << average << endl;
	return 0;
}