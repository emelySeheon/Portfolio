//Program: FileDemo
//Programmer: Rob Garner
//Date: Today
//Purpose: Learn how to use files in C++



#ifndef _FUNCTIONS_H
#define _FUNCTIONS_H
#include <iostream>
#include <string>
#include <fstream>
#include "functions.h"

using namespace std;
void ReadFile(double waterQ[], int &count);
void Average(double array[], int count, double &sum, double &average);




#endif
