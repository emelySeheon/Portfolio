#ifndef _FUNCTIONS_H
#define _FUNCTIONS_H

#include <string>
using namespace std;

bool GetDataFromFile();

#endif // !_FUNCTIONS_H

