
#include <fstream>
#include <iostream>
#include <string>
using namespace std;

bool GetDataFromFile()
{
	ifstream file;
	file.open("DataFile.csv");
	if (!file)
	{
		return false;
	}

	string line;
	while (getline(file, line))
	{
		cout << line << endl;
	};

	return true;
}