/*
Program: Seheon_Q1
Programmer: Emely Seheon
Date: 5/22/20
Purpose: To practice basic coding.
*/

#include <iostream>
using namespace std;

int main()
{
	cout << "Name: Emely Seheon"<<endl;
	cout << "Program Title: Seheon_Q1" << endl;
	cout << "Objective: To practice basic coding" << endl;
	cout << "I have taken all math courses up to Calc 1, and I am currently taking Calc 2." << endl;
	cout << "My favorite thing about coding is being able to create pretty much anything I can imagine with nothing but my fingers." << endl;
	cout << "I don't have much of a programming background; I tried to learn CSS a couple years ago but I wasn't motivated because I was stressed at the time." << endl;
	return 0;
}