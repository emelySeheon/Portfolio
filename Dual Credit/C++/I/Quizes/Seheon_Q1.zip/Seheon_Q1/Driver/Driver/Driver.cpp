/*
Name: Emely Seheon
Email: eseheon1@cnm.edu
File Name: Seheon_Q1
*/