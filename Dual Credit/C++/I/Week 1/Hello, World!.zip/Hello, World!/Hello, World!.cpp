/*
Program: Helloworld.cpp
Programmer: Emely Seheon
Date 5/22/20
Purpose: To learn how to code 'Hello World' in C++
*/

#include <iostream>
using namespace std;

int main()
{
	cout << "Hello, World!" << endl;
	return 0; //return ok
}