/*
Program: Operators Demo
Programmer: Emely Seheon eseheon1@cnm.edu
Date: 5/26/20
Purpose: To learn how to use operators
*/

#include <iostream>
using namespace std;

int main()
{
	//assignment
	int a, b, c;
	a = b = c = 5;
	cout << "a: " << a << " b: " << b << " c: " << c << "\n\n";

	//Fractional Calculations
	double x;
	x = 2 + 5.0 * 4 - 6.0 * 7 / 2;
	cout << "x: " << x << "\n";

	double y;
	y = (2 + 5.0) * 4 - (6.0 * 7 / 2);
	cout << "y: " << y << "\n";

	double z;
	z = 2 + (5.0 * 4 - 6.0) * 7 / 2;
	cout << "z: " << z << "\n";

	double q;
	q = 2 + 5.0 *( 4 - 6.0 * 7 )/ 2;
	cout << "q: " << q << "\n";

	//Wrong and Right ways
	double v,
		a = 1,
		b = 2,
		c = 3,
		d = 4;
	//wrong: v = (a + b)(c - d);
	v = (a + b) * (c - d);
	cout << "v: " << v << "\n";

	double SA, pi = 3.14, rad = 5.5;
	SA = (pi)*(rad)*(rad);
	cout << "SA: " << SA << "\n";

	double m,
		x = 1,
		y = 2,
		w = 3;
	m = sqrt(x*3*y) / w;
	cout << "m: " << m << "\n";

	double angle = 0.5, fofangle;
	fofangle = 2 / 3*sin(x - 0.3);
	cout << "fofangle: " << fofangle << "\n";

	//Increment and Decrement Operators
	int i = 5;
	cout << "i: " << --i << "\n";
	cout << "i: " << i << "\n";

	//Accumulation Operators
	int diff = 7;
	diff -= diff + 10;
	cout << "diff: " << diff << "\n";

	//Modulus Operation
	int mod,
		numerator = 23,
		denominator = 5;
	mod = numerator % denominator;
	cout << "The mod of 23 and 5 is: " << mod << "\n";
	//The modulus is the remainder after a division of two numbers is completed so 23 divided by 5 is 4 with a remainder of 3. 23 mod 5 therefore yields 3.

	//Get user input
	int userInput;
	cout << "Please enter a number: ";
	cin >> userInput;
	cout << "userinput: " << userInput << "\n";

	//simple addition calculator
	double num1, num2, sum;
	cout << "Please enter a number: ";
	cin >> num1;
	cout << "\n Please enter another number: ";
	cin >> num2;
	sum = num1 + num2;
	cout << "\n The sum is: " << sum << "\n";

	return 0;
}