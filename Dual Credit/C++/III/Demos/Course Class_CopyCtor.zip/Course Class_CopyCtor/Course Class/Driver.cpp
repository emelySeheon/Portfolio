//Driver.cpp

#include <iostream>
#include "Course.h"
using namespace std;

void PrintStudent(const string names[], int size)
{
	for (int i = 0; i < size; i++)
		cout << names[i] << (i < size - 1 ? ", " : " ");
	cout<<  " number of students = " << size;
}


int main()
{
	//Shallow copy
	
	/*Course course1("C++ Programming", 10);	
	course1.AddStudent("Peter Pan"); // Add a student to course1

	Course course2(course1);
	cout << "students in course1: " <<
		course1.GetStudents()[0]  
		<< ", number of students: " << course1.GetNumberOfStudents() << endl; 
	cout << "students in course2: " <<
		course2.GetStudents()[0]  
		<< ", number of students: " << course2.GetNumberOfStudents() << endl; 

	course2.AddStudent("Lisa Ma"); // Add a student to course2

	cout << "students in course1: " <<
		course1.GetStudents()[0] << ", " << course1.GetStudents()[1] 
		<< ", number of students: " << course1.GetNumberOfStudents() << endl; 
	cout << "students in course2: " <<
		course2.GetStudents()[0] << ", " << course2.GetStudents()[1] 
		<< ", number of students: " << course2.GetNumberOfStudents() << endl;

	course2.AddStudent("Wylie Coyote"); // Add a student to course2

	cout << "students in course1: " <<
		course1.GetStudents()[0] << ", " << course1.GetStudents()[1] 
		<< ", " << course1.GetStudents()[2] 
		<< ", number of students: " << course1.GetNumberOfStudents() << endl; 
	cout << "students in course2: " <<
		course2.GetStudents()[0] << ", " << course2.GetStudents()[1] 
		<< ", " << course2.GetStudents()[2] 
		<< ", number of students: " << course2.GetNumberOfStudents() << endl; 

	course1.AddStudent("Wonder Woman"); // Add a student to course1

	cout << "students in course1: " <<
		course1.GetStudents()[0] << ", " << course1.GetStudents()[1]
		<< ", " << course1.GetStudents()[2] << ", " << course1.GetStudents()[3] 
		<< ", number of students: " << course1.GetNumberOfStudents() << endl; 
	cout << "students in course2: " <<
		course2.GetStudents()[0] << ", " << course2.GetStudents()[1]
		<< ", " << course2.GetStudents()[2] << ", " << course2.GetStudents()[3] 
		<< ", number of students: " << course2.GetNumberOfStudents() << endl;*/
		

	
	

	//TODO:  Deep Copy
	Course course1("C++ Programming", 10);
	course1.AddStudent("Peter Pan"); // Add a student to course1

	//TODO:  Use copy constructor
	Course course2(course1); // Create course2 as a copy of course1

	course2.AddStudent("Lisa Ma"); // Add a student to course2
	cout << "students in course1: ";
	PrintStudent(course1.GetStudents(), course1.GetNumberOfStudents());
	cout << endl;

	cout << "students in course2: ";
	PrintStudent(course2.GetStudents(), course2.GetNumberOfStudents());
	cout << endl;

	course2.AddStudent("Wylie Coyote"); // Add a student to course2
	cout << "students in course1: ";
	PrintStudent(course1.GetStudents(), course1.GetNumberOfStudents());
	cout << endl;

	cout << "students in course2: ";
	PrintStudent(course2.GetStudents(), course2.GetNumberOfStudents());
	cout << endl;

	course1.AddStudent("Wonder Woman"); // Add a student to course1
	cout << "students in course1: ";
	PrintStudent(course1.GetStudents(), course1.GetNumberOfStudents());
	cout << endl;

	cout << "students in course2: ";
	PrintStudent(course2.GetStudents(), course2.GetNumberOfStudents());
	cout << endl;
	return 0;
}

