//Course.cpp

#include "Course.h"

Course::Course(const string& courseName, int capacity)
{
	
	this-> courseName = courseName;
	this->capacity = capacity;

	students = new string[capacity];
}

Course::Course(const Course& course) // Copy constructor
{
	courseName = course.courseName;
	numberOfStudents = course.numberOfStudents;
	capacity = course.capacity;
	students = new string[capacity];
	for (int i = 0; i < numberOfStudents; i++)
		students[i] = course.students[i];
}

Course::~Course()
{
	delete [] students;
}

string Course::GetCourseName() const
{
	return courseName;
}

void Course::AddStudent(const string& name)
{
	students[numberOfStudents] = name;
	numberOfStudents++;
}

void Course::DropStudent(const string& name)
{
	for(int i = 0; i < numberOfStudents; ++i)
	{
		if(students[i] == name)
			students[i] = "";

		numberOfStudents--;
	}
}

string* Course::GetStudents() const
{
	return students;
}

int Course::GetNumberOfStudents()
{
	return numberOfStudents;
}