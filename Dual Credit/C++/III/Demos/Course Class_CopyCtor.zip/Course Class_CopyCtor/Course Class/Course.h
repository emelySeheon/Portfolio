//Course.h

#ifndef COURSE_H
#define COURSE_H

#include <string>
using namespace std;

class Course
{
private:
	string courseName;
	string* students;
	int numberOfStudents{ 0 };
	int capacity{ 0 };
public:
	Course (const string& courseName, int capacity);
	Course(const Course& course); // Copy constructor
	~Course();
	string GetCourseName() const;
	void AddStudent(const string& name);
	void DropStudent(const string& name);
	string* GetStudents() const;
	int GetNumberOfStudents();
};

#endif