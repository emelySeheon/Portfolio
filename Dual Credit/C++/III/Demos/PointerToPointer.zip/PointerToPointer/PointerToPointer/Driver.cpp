//Ivonne Nelson  inelson1@cnm.edu
//Demo: Pointer to a pointer

//Driver.cpp

#include <iostream>
using namespace std;


int main()
{
	int  var;
	int  *ptr;
	int  **pptr;
	var = 3000;

	// take the address of var
	ptr = &var;
	// take the address of ptr using address of operator &
	pptr = &ptr;

	//So *ptr is value stored in address at ptr = var
	//*pptr = value stored in address of pptr = ptr 
	//*(*pptr) = value stored in the  (value stored in address of pptr) = var	
	
	// take the value using pptr
	cout << "Value of var :" << var << endl;
	cout << "Value available at *ptr :" << *ptr << endl;
	cout << "Value available at **pptr :" << *(*pptr) << endl;

	//We can change the value of var using the dereferencing chain
	**pptr = 1250;
	cout << "Changed var = " << var<<endl<<endl;

	
	return 0;

}