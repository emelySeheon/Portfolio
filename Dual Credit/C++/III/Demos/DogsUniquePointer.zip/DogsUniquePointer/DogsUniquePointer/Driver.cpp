//Unique Pointer Demo

#include <iostream>
#include <memory>
#include <string>

using namespace std;

//class Bone
//{
//public:
//	Bone() { cout << "\n Bone created"; }
//};

class Dog
{	
public:
	string name;
	//Bone *pB;  //old way using raw pointer
	//unique_ptr<Bone> pB;
	Dog() {
		//pB.reset(new Bone()); /*pB = new Bone();*/ 
		name = "Boris";
		cout << "\n Default Dog is created: " << name; 		
	}

	Dog(string name) { 
		this->name = name;
		cout << "\n Dog is created: " << name; 		
	}
	~Dog() {/* delete pB;*/ 
		cout << "\n Dog obj is destroyed: " << name << "\n\n"; 
	}
	void Bark() { 
		cout << "\n " << name << " rules!"; 
	}
};

void F(unique_ptr<Dog> p)
{
	p->Bark();
}

unique_ptr<Dog> GetDog()
{
	unique_ptr<Dog> p(new Dog("Smokey"));
	return p;
	//since the unique pointer is returned by value, it automatically returned using move
	//return move(p);
}

void Test()
{
	//Dog * pD = new Dog("Gunner");  //old way with raw pointer
	unique_ptr<Dog> pD(new Dog("Gunner"));  //use unique pointer
	//F(move(pD));
	//Now call F and pass Gunnar to the function
	//Need to use move semantics
	//WHen F goes out of scope, pD is destroyed.

	//Call GetDog this way:
	unique_ptr<Dog> pD2 = GetDog();

	//can create an array because unique is partially specialized for array, so
	//make sure that the Template parameter of the unique_ptr is an array
	unique_ptr<Dog[]> dogs(new Dog[3]);

	pD->Bark();
	//pD may do a bunch of different things.
	//delete pD;  //no longer have to (or can) delete

	//can retrieve the raw pointer from the unique pointer obj
	//Dog* p = pD.release();
	//This means that pD no longer owns the dog pointer and will not delete it.
	//So you are now responsible to delete the pD pointer, or p as it is now called.

	//Can also use the reset function, which deletes the pointer owned by pD.
	//you can now set the pD unique pointer to a different object:
	pD.reset(new Dog("Smokey"));

	//If we do not set to another pbj, then pD is set to nullPtr.
	pD.reset();

	//what if you want to assign one unique  pointer to another?
	//can't do it by assignment because that involves a copy operation.
	//Let's add another dog, Smokey to a different unique pointer:
	//unique_ptr<Dog> pD2(new Dog("Smokey"));

	//We can use move semantics to move pD2 into the ownership of pD:
	//pD = move(pD2);
	//pD->Bark();
	//This does three things:
	//1.Gunnar is destroyed.
	//2.pD2 becomes empty.
	//3.pD owns Smokey.

	//you can check if pD is a nullptr
	//if (!pD)
	//{
	//	cout << "\n pD is empty.";
	//}
	//else
	//{
	//	cout << "\n pD is not empty.";
	//}

}
int main()
{
	Test();

	return 0;
}

