//Friends demo

#include "Count.h"
using namespace std;

int main()
{
	Count counter;
	cout << "counter.x after instantiation\n";
	counter.Print();

	SetX(counter, 8);
	cout << "counter.x after call to SetX friend function\n";
	counter.Print();

	return 0;
}

