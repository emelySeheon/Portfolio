#ifndef COUNT_H
#define COUNT_H

#include <iostream>
using namespace std;

class Count
{
	friend void SetX(Count& c, int val);  //friend declaration
public:	
	Count() :x{ 0 } {}  //constructor
	void Print() const
	{
		cout << x << endl;
	}
private:
	int x{ 0 };  //data member
};

void SetX(Count& c, int val)
{
	c.x = val;
}
#endif


