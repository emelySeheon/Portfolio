// @topic S-0303-06-01-20 C++ interface 
// @brief class Point, initializer list 
// Storage.h 
#ifndef POINT_H_INCLUDED_ 
#define POINT_H_INCLUDED_ 

class Point 
{ 
private:
	int x{ 0 };
	int y{ 0 };
public: Point( int x, int y ) : x(x), y(y) // initializer list syntax 
		{ 
			//this->x = x; 
			//this->y = y; 
		} 

};//class Point 

#endif //POINT_H_INCLUDED_ 