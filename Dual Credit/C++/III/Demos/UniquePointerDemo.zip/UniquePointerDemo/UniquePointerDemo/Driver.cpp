// @topic S-0303-06-01-10 C++ interface // @brief C++ main function, std::vector, std::unique_ptr, nullptr 
#include  <vector>
#include <memory>
#include "IShape.h" 
#include "Point.h" 
#include "Triangle.h"
#include "Square.h" 

using namespace std;

int main() 
{ 
	Point pt1{ 100, 200 };
	Point pt2{ 400, 600 };
	Point pt3{ 600, 800 };
	vector< unique_ptr< IShape > > shapes; 
	shapes.push_back( unique_ptr< IShape >( new Triangle( pt1, pt2, pt3 ) ) ); 
	shapes.push_back( unique_ptr< IShape >( new Square( pt1, 123 ) ) ); 
	shapes.push_back( unique_ptr< IShape >( nullptr ) ); 

	for(int idx = 0; shapes[idx] != nullptr; ++idx)
		shapes[idx]->draw();
	
	// Compare to using C++ primitive array: // 
	// IShape* shapes[] = { // new Triangle( pt1, pt2, pt3 ), // new Square( pt1, 123 ), // NULL // }; 
	//for ( int idx = 0; shapes[idx] != nullptr; ++idx ) 
	//{ 
	//	shapes[idx]->draw(); 
	//} 
	// If using C++ primitive array: // // 
	//for ( int idx = 0; shapes[idx] != NULL; ++idx ) 
	//{ 
	//	delete shapes[idx]; // 
	//} 
	system( "pause" ); 

	return 0;
} 