
// @topic S-0303-06-01-30 C++ interface
// @brief class Triangle derives from IShape, override keyword

// IShape.h
#ifndef TRIANGLE_H_INCLUDED_
#define TRIANGLE_H_INCLUDED_

#include <iostream>
#include "IShape.h"
#include "Point.h"
using namespace std;

class Triangle : public IShape {
    Point pt1;
    Point pt2;
    Point pt3;
    
public:
    Triangle( Point pt1, Point pt2, Point pt3 )  :
    pt1( pt1 ), pt2( pt2 ), pt3( pt3 )
    {
        //this->pt1 = pt1;
        //this->pt2 = pt2;
        //this->pt3 = pt3;
    }
    
    //@Override
    void draw() override
    {
        cout<< "Triangle\n" ;
    }
};//class Triangle

#endif //TRIANGLE_H_INCLUDED_
