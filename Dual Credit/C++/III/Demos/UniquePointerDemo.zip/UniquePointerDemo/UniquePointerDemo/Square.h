
// @topic S-0303-06-01-40 C++ interface
// @brief class Square derives from IShape

// Storage.h
#ifndef SQUARE_H_INCLUDED_
#define SQUARE_H_INCLUDED_

#include <iostream>
#include "IShape.h"
#include "Point.h"

using namespace std;


class Square : public  IShape {
    Point topLeft;
	int sideLength{ 0 };

public:
    Square( Point topLeft, int sideLength ):
    topLeft( topLeft ), sideLength( sideLength )
    {
        //this.topLeft = topLeft;
        //this.sideLength = sideLength;
    }
    
    //@Override
    void draw() override
    {
        cout<<"Square\n";
    }
};//class Square

#endif //SQUARE_H_INCLUDED_