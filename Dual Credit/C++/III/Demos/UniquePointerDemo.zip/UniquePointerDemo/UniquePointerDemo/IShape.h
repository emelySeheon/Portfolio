// @topic S-0303-06-01-20 C++ interface 
// @brief IShape interface 

// IShape.h 

#ifndef ISHAPE_H_INCLUDED_ 
#define ISHAPE_H_INCLUDED_ 
#include <iostream>
class IShape 
{ 
public: virtual void draw() = 0; 
		virtual ~IShape() { std::cout << "destructing IShape"; }
};


#endif//ISHAPE_H_INCLUDED
