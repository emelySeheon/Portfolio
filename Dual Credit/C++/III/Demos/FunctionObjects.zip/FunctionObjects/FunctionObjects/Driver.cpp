//

#include <iostream>
using namespace std;

class Functor
{
public:
    int operator()(int a, int b)
    {
        return a < b;
    }
};

int main()
{
    Functor func;
    int a = 5;
    int b = 7;
    int ans = func(a, b);
    if (!ans)
        cout << "\n a is not less than b"<<endl;
    else
        cout << "\n a is less than b"<<endl;

    return 0;
}

    