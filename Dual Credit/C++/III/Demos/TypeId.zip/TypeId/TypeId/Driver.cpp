

// C++ program to show the use of typeid operator 

#include <iostream> 
#include <typeinfo> 
using namespace std;

int main()
{
	int i, j;
	char c;

	// Get the type info using typeid operator 
	const type_info& ti1 = typeid(i);
	const type_info& ti2 = typeid(j);
	const type_info& ti3 = typeid(c);

	// Check if both types are same 
	if (ti1 == ti2)
		cout << "i and j are of"
		<< " simiar type" << endl;
	else
		cout << "i and j are of"
		<< " different type" << endl;

	// Check if both types are same 
	if (ti2 == ti3)
		cout << "j and c are of"
		<< " simiar type" << endl;
	else
		cout << "j and c are of"
		<< " different type" << endl;

	cout << "\n\n typeid works on expressions\n";

	i = 5;
	double jj = 1.0;
	c = 'a';

	// Get the type info using typeid operator 
	const type_info& ti4 = typeid(i * jj);
	const type_info& ti5 = typeid(i * c);
	const type_info& ti6 = typeid(c);

	// Print the types 
	cout << "ti4 is of type "
		<< ti4.name() << endl;

	cout << "ti5 is of type "
		<< ti5.name() << endl;

	cout << "ti6 is of type "
		<< ti6.name() << endl;


cout << "\n\n typeid works on objects\n";
class Base {
public:
	virtual void vvfunc() {}
};

class Derived : public Base {};


	Derived* pd = new Derived;
	Base* pb = pd;
	
	cout << typeid(pb).name() << endl;   //prints "class Base *"
	cout << typeid(*pb).name() << endl;   //prints "class Derived"
	cout << typeid(pd).name() << endl;   //prints "class Derived *"
	cout << typeid(*pd).name() << endl;   //prints "class Derived"
	delete pd;

	return 0;
}





