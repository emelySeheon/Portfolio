//Squares.cpp

#include "Squares.h"



Squares::Squares(int len)
{
    length = len;
    sq = new int[length];
    for (int k = 0; k < length; k++)
    {
        sq[k] = (k+1)*(k+1);
    }
    // Trace
    cout << "\n Construct an object of size " << length << endl;
}
// Return a string containing the sequence
string Squares::GetSquares()
{
    stringstream ss;
    for (int k = 0; k < length; k++)
        ss << sq[k] << "  ";
    ss<<endl;
    return ss.str();
}
// Destructor deallocates storage
Squares::~Squares()
{
    delete [ ] sq;
    // Trace
    cout << " Destructor for object of size " << length <<  endl<<endl;
}