// This program illustrates the use of constructors
// and destructors in the allocation and deallocation of memory.
#include <iostream>
#include <string>
#include "Squares.h"
using namespace std;

void outputSquares(Squares *sqPtr);

int main()
{

    cout << "\n Demo of dynamic allocation of an array of ints in a class.\n";
    Squares sqs(5);
    cout << " The first 5 squares are: ";
    cout<< sqs.GetSquares();

    //// Main allocates a Squares object on the free store
    Squares *sqPtr = new Squares(3);
    cout << "\n address of sqPtr in main " << &sqPtr
        <<"\n the value of sqPtr in main " << sqPtr <<endl;
    outputSquares(sqPtr);
    // Main deallocates the dynamic Squares object
    delete sqPtr;

    return 0;
}

//***********************************************
// Outputs the sequence of squares in a         *
// Squares object                               *
//***********************************************
void outputSquares(Squares *sqPtr)
{
    cout << "\n address of sqPtr in function " << &sqPtr
        <<"\n the value of sqptr in function " << sqPtr<<endl;
    cout << " The list of squares is: ";
    cout<< sqPtr->GetSquares();

}