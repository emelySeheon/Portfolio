//Squares.h

#ifndef SQUARES_H
#define SQUARES_H

#include <string>
#include <iostream>
#include <sstream>
using namespace std;

class Squares
{
private:
	int length{ 0 };  // How long is the sequence
    int *sq;     // Dynamically allocated array
public:
    // Constructor allocates storage for sequence
    // of squares and creates the sequence
    Squares(int len);
	~Squares();
	string GetSquares();	
};

#endif