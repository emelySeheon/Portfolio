//Ivonne Nelson
//StackUnwinding example
//CIS2277

//Functions.cpp

#include "Functions.h"

void C(Dummy d, int i)
{
	cout << "\n Entering Function C" << endl;
	d.MyName = " C";
	throw MyException();

	cout << "\n Exiting Function C" << endl;
}

void B(Dummy d, int i)
{
	cout << "\n Entering Function B" << endl;
	d.MyName = " B";
	C(d, i + 1);
	cout << "\n Exiting Function B" << endl;
}

void A(Dummy d, int i)
{
	cout << "\n Entering Function A" << endl;
	d.MyName = " A";
	Dummy* pd = new Dummy(" New Dummy"); //Not exception safe!!!  
	pd->MyName = " pd";
	B(d, i + 1);
	delete pd;   
	cout << "\n Exiting Function A" << endl;
}