//Ivonne Nelson
//StackUnwinding example
//CIS2277

//Functions.h

#ifndef FUNCTIONS_H
#define FUNCTIONS_H

#include "Dummy.h"

void C(Dummy d, int i);

void B(Dummy d, int i);

void A(Dummy d, int i);

#endif
