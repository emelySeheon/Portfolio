//Ivonne Nelson
//StackUnwinding example
//CIS2277

//Dummy.h


#ifndef DUMMY_H
#define DUMMY_H

#include <string> 
#include <iostream>  

using namespace std;

class Dummy
{
public:
	Dummy(string s) : MyName(s) { PrintMsg("Created Dummy:"); }
	Dummy(const Dummy& other) : MyName(other.MyName) { PrintMsg("Copy created Dummy: "); }
	~Dummy() { PrintMsg("Destroyed Dummy:"); }
	void PrintMsg(string s) { cout << s << MyName << endl; }
	string MyName;
	int level;
};


class MyException {};
#endif
