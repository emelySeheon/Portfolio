//Ivonne Nelson
//StackUnwinding example
//CIS2277

//Driver.cpp

#include <string>  
#include <iostream> 
#include "Dummy.h"
#include "Functions.h"
using namespace std;

int main()
{
	cout << "\n Entering main" << endl;
	try
	{
		Dummy d(" Main");
		A(d, 1);
	}
	catch (MyException& e)
	{
		cout << "\n Caught an exception of type: " << typeid(e).name() << endl;
	}

	cout << "\n Exiting main." << endl<<endl;
	

	return 0;
}
