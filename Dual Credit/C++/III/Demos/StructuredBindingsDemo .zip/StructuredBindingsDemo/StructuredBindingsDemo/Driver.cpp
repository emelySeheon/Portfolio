//StructuredBindingsDemo
//Driver.cpp

#include <iostream>
#include <tuple>
#include <string>

using namespace std;

tuple<string, int> CreatePerson()
{
	return { "Ivonne", 42 };
}

int main()
{
	//C++14
	auto person = CreatePerson();
	string name = get <0>(person);
	int age = get<1>(person);
	cout << "\n name " << name << "  age " << age << endl << endl;

	//OR
	//string name;
	//int age;
	//tie(name, age) = CreatePerson();
	//cout << "\n name " << name << "  age " << age << endl << endl;

	//C++17
	//auto [name, age] = CreatePerson();

	//cout << "\n name = " << name << " age = " << age << endl<< endl;
	return 0;
}