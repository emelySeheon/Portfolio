//Ivonne Nelson
//Towers of Hanoi - recursion

//Driver.cpp
#include <iostream>
using namespace std;

void Move(int count, int start, int finish, int temp);

int main()
{

	int count = 3;
	Move(count, 1, 3, 2);
	return 0;
}

void Move(int count, int start, int finish, int temp)
{
	if (count > 0)
	{
		int smCount = count - 1;
		Move(smCount, start, temp, finish);
		cout << "Move disc " << count << " from tower "
			<< start << " to " << finish << "." << endl;
		Move(count - 1, temp, finish, start);
	}
}
