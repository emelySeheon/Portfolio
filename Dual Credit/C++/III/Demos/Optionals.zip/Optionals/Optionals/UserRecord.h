//

#ifndef USER_FILES_H
#define USER_FILES_H
#include <string>
#include <optional>
#include <iostream>
using namespace std;

class UserRecord
{
public:
    UserRecord(const string& name, optional<string> nick, optional<int> age)
        : name{ name }, nick{ nick }, age{ age }
    {
    }
    friend ostream& operator << (ostream& stream, const UserRecord& user);
private:
    string name;
    optional<string> nick;
    optional<int> age;
};

ostream& operator << (ostream& os, const UserRecord& user)
{
    os << user.name << ' ';
    if (user.nick) {
        os << *user.nick << ' ';
    }
    if (user.age)
        os << "age of " << *user.age;
    return os;
}



#endif