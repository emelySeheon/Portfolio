//
#include "UserRecord.h"


int main()
{
    UserRecord tim{ "Tim", "SuperTim", 16 };
    UserRecord nano{ "Nathan", nullopt, nullopt };
    cout << tim << "\n";
    cout << nano << "\n";

    return 0;
}
