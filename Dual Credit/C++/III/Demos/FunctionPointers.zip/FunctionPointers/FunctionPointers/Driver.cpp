//Ivonne Nelson  inelson1@cnm.edu
//Demos

//Driver.cpp

//Function Pointers

#include <iostream>
using namespace std;

bool LengthCompare(const string& str1, const string& str2);

int main()
{
	bool(*fp)(const string& str1, const string& str2); //Declare a function pointer 
	fp = &LengthCompare; //fptr -> one
	bool b1 = fp("hello", "good-bye"); //=>LengthCompare
	b1 ? cout << "\n True, str1 is longer than str2": cout << "\n False, str1 is not longer than str2";
	bool b2 = (*fp)("hello", "good-bye"); //=> LengthCompare
	b2 ? cout << "\n True, str1 is longer than str2" : cout << "\n False, str1 is not longer than str2";
	cout<< endl;

	return 0;
}
bool LengthCompare(const string& str1, const string& str2)
{
	if (str1 > str2)
		return true;
	else
		return false;
}
