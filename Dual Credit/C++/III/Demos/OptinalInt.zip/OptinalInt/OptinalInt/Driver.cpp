

#include <iostream>
#include <string>
#include <optional>

using namespace std;

int main()
{
	// by operator*
	optional<int> oint = 10;
	cout << "oint " << *oint << '\n';
	// by value()
	optional<string> ostr("hello");
	try
	{
		cout << "ostr " << ostr.value() << '\n';
	}
	catch (const bad_optional_access& e)
	{
		std::cout << e.what() << "\n";
	}
	// by value_or()
	optional<double> odouble; // empty
	cout << "odouble " << odouble.value_or(10.0) << '\n';



	return 0;

}