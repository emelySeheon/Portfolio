#pragma once

#include <algorithm>
#include <iostream>
class Holder
{
public:
	Holder(int size)         // Constructor
	{
		std::cout<<"\n In Holder Constructor";
		data = new int[size];
		this->size = size;
	}
	Holder(const Holder& other)  //Copy Constructor
	{
		std::cout << "\n In Holder Copy Constructor";
		data = new int[other.size];  // create a new array of the same size
		std::copy(other.data, other.data + other.size, data);  // Copy the data from  other.data into this-> data.
		this->size = other.size;
	}
	Holder& operator=(const Holder& other)
	{
		std::cout << "\n In Holder Assignment Operator";
		if (this == &other) return *this;  // Check for self-assignment
		delete[] data;  // delete current data so it can be replaced
		
		this->data = new int[other.size];
		std::copy(other.data, other.data + other.size, data);
		this->size = other.size;
		return *this;  // return a reference to this class
	}


	~Holder()                // Destructor
	{
		std::cout << "\n In Holder Destructor";
		delete[] data;
	}
private:
	int* data;
	size_t size;

};

