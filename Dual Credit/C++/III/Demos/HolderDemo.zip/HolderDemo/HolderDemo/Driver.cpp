//Ivonne Nelson
//Move Semantics Demo

#include "Holder.h"
Holder CreateHolder(int size);


int main()
{
	Holder h1(1000);                // regular constructor
	Holder h2(h1);                  // copy constructor (lvalue in input)
	Holder h3 = CreateHolder(2000); // move constructor (rvalue in input)  
	h2 = h3;                        // assignment operator (lvalue in input)
	h2 = CreateHolder(500);  // move assignment operator (rvalue in input)

	return 0;
}
Holder CreateHolder(int size)
{
	return Holder(size);
}
