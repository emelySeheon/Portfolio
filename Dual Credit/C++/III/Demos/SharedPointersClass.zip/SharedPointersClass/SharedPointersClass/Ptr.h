//Template class for Ptr
//Ptr.h

#ifndef PTR_H
#define PTR_H
#include "ReferenceCounter.h"
#include <iostream>



template <class T>
class Ptr
{
public:

	Ptr() : data(0), ref(0)
	{
		ref = new ReferenceCounter();
		std::cout << "\n  Constructing Ptr" << std::endl;
		ref->Add();		
	}

	Ptr(T* d) : data(d), ref(0)
	{
		ref = new ReferenceCounter();
		std::cout << "\n  Constructing Ptr" << std::endl;
		ref->Add();
	}

	// Copy constructor  
	Ptr(const Ptr<T>& ptr) : data(ptr.data), ref(ptr.ref)
	{
		// Copy constructor  
			// Copy the data and reference pointer  
			// and increment the reference count 
		std::cout << "\n  Copy Constructor Ptr" << std::endl;
		ref->Add();
	}

	// Assignment operator  
	Ptr<T>& operator = (const Ptr<T>& ptr)
	{

		std::cout << "\n Assigning Ptr" << std::endl;
		// Assignment operator  
		if (this != &ptr) // Avoid self assignment  
		{
			// Decrement the old reference count  
				// if reference become zero delete the old data  
			if (ref->Release() == 0)
			{
				delete data;
				delete ref;
			}

			// Copy the data and reference pointer  
			// and increment the reference count  
			data = ptr.data;
			ref = ptr.ref;
			ref->Add();
		}
		return *this;
	}

	~Ptr()
	{

		std::cout << "\n  Destructing Ptr" << std::endl;
		// Only when ref. count reaches 0 delete data  
		if (ref->Release() == 0)
		{
			delete data;
			delete ref;
		}
	}

	T* operator->() { return data; }
	T& operator*() { return *data; }

private:
	T* data;
	ReferenceCounter* ref;
};


#endif
