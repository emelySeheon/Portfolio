//class A

//A.h

#ifndef A_H
#define A_H

#include <iostream>
class A
{
public:
	A() { std::cout << "\n  Constructing A" << std::endl; }
	~A() { std::cout << "\n  Destructing A" << std::endl; }
	void DoStuff() { std::cout << "\n  Hello to DoStuff()" <<std::endl; }
};

#endif

