//Reference Counter class
//ReferenceCounter.h

#ifndef REFERENCE_COUNTER_H
#define REFERENCE_COUNTER_H
#include <iostream>

class ReferenceCounter
{
private:
	int count;

public:
	void Add()
	{
		count++;

		std::cout << "\n  count = " << count << std::endl;
	}

	// Decrement and release reference count  
	int Release()
	{
		 --count;
		 std::cout << "\n  count = " << count << std::endl;
		 return count;
	}
};

#endif

