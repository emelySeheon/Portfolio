//Ivonne Nelson

//Shared Pointer Class

//Driver.cpp

#include "A.h"
#include "Ptr.h"
#include <iostream>

void FunctionA(Ptr<A> x)
{
	Ptr<A> q = x;
	q->DoStuff();
	// Destructors of q and x will be called here  
}

void FunctionB()
{
	Ptr<A> r(new A());	
	r->DoStuff();
	// Destructor of r will be called here  
}
	int main()
	{
		std::cout << "\n  Starting in main" << std::endl;
		Ptr<A> p(new A());
		p->DoStuff();			

		std::cout << "\n  Calling FunctionA" << std::endl;
		FunctionA(p);

		std::cout << "\n  Back in main, calling FunctionB" << std::endl;
		FunctionB();
		
		std::cout << "\n  Back in main" << std::endl;
		p->DoStuff();
     
		// Destructor of p will be called here  
		    return 0;
	}
