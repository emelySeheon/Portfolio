//Placement New Destruction Demo

#ifndef _COMPLEX_H
#define _COMPLEX_H

#include<iostream> 
//#include<cstdlib> 
#include<cmath> 
using namespace std;

class Complex
{

private:
    double re, im;
public:
    // Constructor 
    Complex(double re = 0, double im = 0) : re(re), im(im)
    {
        cout << "Constructor : (" << re
            << ", " << im<< ")" << endl;
    }

    // Destructor 
    ~Complex()
    {
        cout << "Destructor : (" << re << ", "
            << im << ")" << endl;
    }

    double normal()
    {
        return sqrt(re * re + im * im);
    }

    void print()
    {
        cout << "|" << re << " +j" << im
            << " | = " << normal() << endl;
    }
};

#endif

