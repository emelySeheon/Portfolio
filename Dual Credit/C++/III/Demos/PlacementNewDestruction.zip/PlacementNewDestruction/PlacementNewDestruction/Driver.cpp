//Placement New Destruction Demo

#include "Complex.h"

// Driver code 
int main()
{
    // buffer on stack 
    unsigned char buf[100];

    Complex* pc = new Complex(4.2, 5.3);
    Complex* pd = new Complex[2];

    // using placement new 
    Complex* pe = new (buf) Complex(2.6, 3.9);

    // use objects 
    pc->print();
    pd[0].print();
    pd[1].print();
    pe->print();

    // Release objects 
    // calls destructor and then release memory 
    delete pc;

    // Calls the destructor for object pd[0] 
    // and then release memory 
    // and it does same for pd[1] 
    delete[] pd;

    // No delete : Explicit call to Destructor. 
    pe->~Complex();

    return 0;
}

/*Here the destructor is explicitly called because here it cannot be packaged within the 
delete operator because delete will need to release the memory which you do not have here 
and it cannot be implicit as it is a dynamic process which we want to mange yourself.*/