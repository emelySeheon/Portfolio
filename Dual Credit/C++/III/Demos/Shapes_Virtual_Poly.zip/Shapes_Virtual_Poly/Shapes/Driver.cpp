//File: Driver.cpp

#include <iostream>
#include "Shapes.h"
using namespace std;

int main()
{
	cout<<"\n The Virtual Shape Program"<<endl;	
	cout<<"\n Destructing a derived class object using the base class pointer"
		<<"\n That is, doing it polymorphically.";


	Shape *pS = new Pyramid;
	delete pS;
	pS = nullptr;


	//Pyramid *pP = new Pyramid;
	//delete pP;

	cout<<endl<<endl;
	return 0;
}
