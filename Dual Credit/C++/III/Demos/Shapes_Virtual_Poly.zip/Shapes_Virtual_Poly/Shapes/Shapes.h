//File:  Shapes.h

#ifndef _SHAPES_H
#define _SHAPES_H

#include <iostream>
using namespace std;

class Shape
{
public:
	Shape(){ cout<<"\n Constructing Shape";}
	 virtual ~Shape(){ cout<<"\n Destroying Shape";}
	
};

class Pyramid:public Shape
{
public:
	Pyramid(){ cout<<"\n Constructing Pyramid";}
	 ~Pyramid(){ cout<<"\n Destroying Pyramid";}	
};


#endif



