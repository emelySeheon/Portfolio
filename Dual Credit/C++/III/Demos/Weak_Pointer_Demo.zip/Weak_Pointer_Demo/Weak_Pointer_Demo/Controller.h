#include <iostream>
#include <memory>
#include <string>
#include <vector>
#include <algorithm>

using namespace std;

class Controller
{
public:
	int Num;
	wstring Status;
	vector<shared_ptr<Controller>> others;
	//vector<weak_ptr<Controller>> others;
	explicit Controller(int i) : Num(i), Status(L"On")
	{
		wcout << L"Creating Controller" << Num << endl;
	}

	~Controller()
	{
		wcout << L"Destroying Controller" << Num << endl;
	}

	// Demonstrates how to test whether the  
	// pointed-to memory still exists or not. 
	void CheckStatuses() const
	{
		for_each(others.begin(), others.end(), [](weak_ptr<Controller> wp)
		{
			try
			{
				auto p = wp.lock();
				wcout << L"Status of " << p->Num << " = " << p->Status << endl;
			}

			catch (bad_weak_ptr b)
			{
				wcout << L"Null object" << endl;
			}
		});
	}
};

