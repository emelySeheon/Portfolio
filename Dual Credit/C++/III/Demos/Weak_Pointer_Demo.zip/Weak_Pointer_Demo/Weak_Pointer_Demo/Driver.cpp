

#include "Controller.h"

using namespace std;

/*The following code example shows a case where weak_ptr is used to ensure proper deletion of 
objects that have circular dependencies. As you examine the example, assume that it was created 
only after alternative solutions were considered. The Controller objects represent some aspect 
of a machine process, and they operate independently. Each controller must be able to query the 
status of the other controllers at any time, and each one contains a private 
vector<weak_ptr<Controller>> for this purpose. Each vector contains a circular reference, and 
therefore, weak_ptr instances are used instead of shared_ptr*/

/*As an experiment, modify the vector others (in the Controller class) to be a 
vector<shared_ptr<Controller>>, and then in the output, notice that no destructors 
are invoked when TestRun returns.*/


void RunTest()
{
	vector<shared_ptr<Controller>> v;

	v.push_back(shared_ptr<Controller>(new Controller(0)));
	v.push_back(shared_ptr<Controller>(new Controller(1)));
	v.push_back(shared_ptr<Controller>(new Controller(2)));
	v.push_back(shared_ptr<Controller>(new Controller(3)));
	v.push_back(shared_ptr<Controller>(new Controller(4)));

	// Each controller depends on all others not being deleted. 
	// Give each controller a pointer to all the others. 
	for (int i = 0; i < v.size(); ++i)
	{
		/*This is a C++ lambda.  
		v and i are local variables that are captured to be used in the lambda's function.
		shared_ptr<Controller> p is the parameter being passed in
		The return is void*/

		for_each(v.begin(), v.end(), [v, i](shared_ptr<Controller> p)
		{
			if (p->Num != i)
			{
				//v[i]->others.push_back(weak_ptr<Controller>(p));
				v[i]->others.push_back(shared_ptr<Controller>(p));
				wcout << L"push_back to v[" << i << "]: " << p->Num << endl;
			}
		});
	}

	for_each(v.begin(), v.end(), [](shared_ptr<Controller>& p)
	{
		wcout << L"use_count = " << p.use_count() << endl;
		p->CheckStatuses();
	});
}

int main()
{
	RunTest();
//	wcout << L"Press any key" << endl;
//	char ch;
//	cin.getline(&ch, 1);
}