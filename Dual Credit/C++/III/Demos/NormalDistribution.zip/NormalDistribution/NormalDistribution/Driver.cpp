#include <iostream>
#include <iomanip>
#include <string>
#include <map>
#include <random>
#include <cmath>

using namespace std;
 
int main()
{
 
  // Choose a random mean between 1 and 6
 default_random_engine e1;
    uniform_int_distribution<int> uniform_dist(1, 6);
    int mean = uniform_dist(e1);
    cout << "Randomly-chosen mean: " << mean << '\n';
 
  //  // Generate a normal distribution around that mean
  //  mt19937 e2(rd());
    normal_distribution<> normal_dist(mean, 2.0);
 
    map<int, int> hist;
    for (int n = 0; n < 10000; ++n) {
		double t = normal_dist(e1);
        ++hist[static_cast<int>(t >=0 ? t + 0.5 : t - 0.5 )];
    }
    cout << "Normal distribution around mean of 10.0 :\n";
    for (auto p : hist) {
        cout << fixed << setprecision(1) << setw(2)
                  << p.first << ' ' << string(p.second/50, '*') << '\n';
	}

	cout <<endl<<endl;
	return 0;
}
