// Fig. 12.10: Employee.cpp
// Abstract-base-class Employee member-function definitions.
// Note: No definitions are given for pure virtual functions.
#include <iostream>
#include "Employee.h" // Employee class definition
using namespace std;

// constructor
Employee::Employee( const string &first, const string &last,
   const string &ssn )
   : firstName( first ), lastName( last ), socialSecurityNumber( ssn )
{
   // empty body 
} // end Employee constructor

// set first name
void Employee::SetFirstName( const string &first ) 
{ 
   firstName = first;  
} // end function setFirstName

// return first name
string Employee::GetFirstName() const 
{ 
   return firstName;  
} // end function getFirstName

// set last name
void Employee::SetLastName( const string &last )
{
   lastName = last;   
} // end function setLastName

// return last name
string Employee::GetLastName() const
{
   return lastName;   
} // end function getLastName

// set social security number
void Employee::SetSocialSecurityNumber( const string &ssn )
{
   socialSecurityNumber = ssn; // should validate
} // end function setSocialSecurityNumber

// return social security number
string Employee::GetSocialSecurityNumber() const
{
   return socialSecurityNumber;   
} // end function getSocialSecurityNumber

// print Employee's information (virtual, but not pure virtual)
void Employee::Print() const
{ 
   cout << firstName << ' ' << lastName 
      << "\nsocial security number: " << socialSecurityNumber; 
} // end function print


