// Fig. 12.11: SalariedEmployee.h
// SalariedEmployee class derived from Employee.
#ifndef SALARIED_H
#define SALARIED_H

#include <string> // C++ standard string class
#include "Employee.h" // Employee class definition
using namespace std;

class SalariedEmployee : public Employee 
{
public:
   SalariedEmployee( const string &first, const string &last, 
      const string &ssn, double = 0.0 );
   virtual ~SalariedEmployee() { } // virtual destructor

   void SetWeeklySalary( double ); // set weekly salary
   double GetWeeklySalary() const; // return weekly salary

   // keyword virtual signals intent to override
   virtual double Earnings() const override; // calculate earnings
   virtual void Print() const override; // print object
private:
   double weeklySalary; // salary per week
}; // end class SalariedEmployee

#endif // SALARIED_H


