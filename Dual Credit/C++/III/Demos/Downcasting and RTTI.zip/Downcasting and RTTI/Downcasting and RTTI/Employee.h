// Fig. 12.9: Employee.h
// Employee abstract base class.
#ifndef EMPLOYEE_H
#define EMPLOYEE_H

#include <string> // C++ standard string class
using namespace std;

class Employee 
{
public:
   Employee( const string &first, const string &last, 
      const string &ssn );
   virtual ~Employee() { } // virtual destructor

   void SetFirstName( const string & ); // set first name
   string GetFirstName() const; // return first name

   void SetLastName( const string & ); // set last name
   string GetLastName() const; // return last name

   void SetSocialSecurityNumber( const string & ); // set SSN
   string GetSocialSecurityNumber() const; // return SSN

   // pure virtual function makes Employee abstract base class
   virtual double Earnings() const = 0; // pure virtual
   virtual void Print() const; // virtual
private:
   string firstName;
   string lastName;
   string socialSecurityNumber;
}; // end class Employee

#endif // EMPLOYEE_H


