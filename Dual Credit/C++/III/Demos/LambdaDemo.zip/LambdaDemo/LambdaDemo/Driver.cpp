//Ivonne Nelson inelson1@cnm.edu

//Lambda Demo

//Driver.cpp

#include <iostream>  
using namespace std;

int main()
{
	int m = 0;
	int n = 0;
	[&m, n](int a) mutable { m = ++n + a; }(4);
	cout << "\n m is " << m << endl 
		<<"\n n is " << n << endl<< endl;
	return 0;
}

/*  
[&m, n] are the capture list. n can be used in the lambda body, and m is captured by reference and by 
		using the mutable keyword, can be modified in the lambda.
(int a) is the parameter list of inputs to the lambda.

{ m = ++n + a; } is the lambda body
(4) is the argument to the lambda 
m = 5, n = 0  */

