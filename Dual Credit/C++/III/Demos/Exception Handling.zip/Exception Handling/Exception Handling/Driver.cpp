// Exception handling and new

#include <iostream>
#include <new>
#include <string>
using namespace std;

int main()
{
	int *int_pointer, size;

	cout<<"\n\n Enter the size of your 1-dimensional array:  ";
	cout<<"\n ========>";
	cin>>size;


	/**********************************************
	Using try/catch the bad_alloc exception
	***********************************************/
	//try
	//{
	//	int_pointer = new int[size];	//memory for a lot of ints
	//	cout <<"\n If we make it to this line, no exception was thrown.";
	//}
	//catch( bad_alloc& ba)
	//{
	//	cerr<<"\n\n bad_alloc caught: "
	//		<< ba.what()  <<"\n  Not enough memory, sorry.";
	//}
	//cout<<"\n Check out that catch!";

	/*************************************************
	Using nothrow version of the new operator
	**************************************************/
	//int_pointer = new(nothrow) int[size];	//memory for a lot of ints
	//if(int_pointer == nullptr)
	//	cerr<<"\n Allocation returned null pointer";
	//else
	//	cout <<"\n If we make it to this line, allocation OK.";

	////clean up any successes
	//if(int_pointer != nullptr)
	//	delete int_pointer;

	/*************************************************
	Crashing when you use a pointer that has been deleted already
	**************************************************/

	string *pStr = new string;
	delete pStr;
	pStr = nullptr;

	cout<<"\n\n Crashing when using a dangling pointer";
	/*pStr->assign("New String");*/
	if(pStr != nullptr)
	{
		char c = pStr->at(0); 
		
	}


	cout<<endl<<endl;
	return 0;
}



