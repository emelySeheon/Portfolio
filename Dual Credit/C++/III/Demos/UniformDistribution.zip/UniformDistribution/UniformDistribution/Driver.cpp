//Ivonne Nelson
//C++11 Random class

#include <random>
#include <iostream>
#include <chrono>
using namespace std;

void DisplaySix(unsigned char iNumber)
{
  unsigned int iDisplay;

  /*Default random engine
 This is a random number engine class that generates pseudo-random numbers. 
 It is the library implemention's selection of a generator that provides 
 at least acceptable engine behavior for relatively casual, inexpert, 
 and/or lightweight use.*/

  default_random_engine engine;

  /*Random number distribution that produces integer 
  values according to a uniform discrete distribution, 
  which is described by the following probability mass function:
  This distribution produces random integers in a range [a,b] 
  where each possible value has an equal likelihood of being 
  produced. This is the distribution function that appears on 
  many trivial random processes (like the result of rolling a die).
 
  The distribution parameters, a and b, are set on construction.
 
  To produce a random value following this distribution, 
  call its member function operator().*/

  uniform_int_distribution<int>distribution(1,6);
  do
  {
    iDisplay=distribution(engine);
    cout << iDisplay;
    cout << "\n";
    iNumber--;
  }
  while(iNumber>0);
  
}

void UseSeed()
{
  //Using a seed
  // uniform_int_distribution::operator()

  // construct a trivial random generator engine from a time-based seed:
  unsigned seed = static_cast<unsigned>(chrono::system_clock::now().time_since_epoch().count());
  default_random_engine generator (seed);

  uniform_int_distribution<int> distribution(1,10);

  cout << "some random numbers between 1 and 10: ";
  for (int i=0; i<10; ++i)
    cout << distribution(generator) << " ";

  cout << endl;
  
}
 
int main()
{
    DisplaySix(10);
	UseSeed();
	return 0;
}