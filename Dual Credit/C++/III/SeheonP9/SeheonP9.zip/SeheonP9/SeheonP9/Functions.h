#ifndef FUNCTIONS_H
#define FUNCTIONS_H

#include <sstream>
#include "StudentUser.h"

using namespace std;

//header
string WriteHeader();
//Determines how many students
int HowManyUsers();

#endif